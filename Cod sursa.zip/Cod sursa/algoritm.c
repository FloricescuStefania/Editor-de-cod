#include <string.h>
#include "algoritm.h"

int min(int x, int y, int z)
{
    if (x <= y && x <= z)
        return x; // x reprezinta operatia de substituire
    if (y <= x && y <= z)
        return y; // y reprezinta operatia de inserare
    else
        return z; // z reprezinta operatia de stergere
    // prin aceata functie verificam care operatie efectueaza un numar minim de pasi
}

int pasi_min(char fragment_de_cod[], char regula[])
{
    int m = strlen(fragment_de_cod);
    // m primeste valoarea lungimii sirului fragment_de_cod
    int n = strlen(regula);
    // n primeste valoarea lungimi sirului regula
    int editor[m + 1][n + 1];
    //stocam valorile in matricea "editor"

    for (int i = 0; i <= m; i++)
        editor[i][0] = i;
        // Se initializeaza prima coloana cu valorile de la 0 la m, reflectand numarul de pasi ai transformarii unui sir gol in fragment_de_cod.
           for (int j = 0; j <= n; j++)
             editor[0][j] = j;
        // Se initializeaza primul rand cu valorile de la 0 la n, reflectand numarul de pasi ai transformarii unui sir gol in regula.

    for (int i = 1; i <= m; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (fragment_de_cod[i - 1] == regula[j - 1])
                editor[i][j] = editor[i - 1][j - 1]; // cele doua siruri sunt identice,nu necesita pasi de modificare
            else
                editor[i][j] = min(editor[i - 1][j - 1] + 1, // substituire de caractere
                                   editor[i][j - 1] + 1,     // insertie
                                   editor[i - 1][j] + 1);    // stergere
        }
    }

    return editor[m][n];
}

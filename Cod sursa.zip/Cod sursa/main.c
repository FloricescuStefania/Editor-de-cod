#include <stdio.h>
#include "algoritm.h"

#define LUNGIME_MAX 1000 //definim lungimea maximă a șirurilor citite din fișier

int main() {
    char fragment_de_cod[LUNGIME_MAX]; //
    char regula[LUNGIME_MAX]; //
    FILE *file = fopen("data.txt", "r"); //deschidem fisierul

    if (file == NULL)
    {
        printf("Fisierul nu s-a deschis.\n");
    }
    else
    {
        printf("Fisierul s-a deschis.\n");
    }
    //in aceasta bucla IF se verifica daca fisierul poate fi deschis

    while (fscanf(file, "%s %s", fragment_de_cod, regula) != EOF) {
        //citim perechi de șiruri de caractere din fișierul data.txt folosind fscanf() până la end of file
        int pasi = pasi_min(fragment_de_cod, regula);
        //calculam numarul minim de pasi dintre cele doua siruri

        printf("\nFragment_de_cod: %s\n", fragment_de_cod);
        printf("Regula: %s\n", regula);
        printf("Pasi_min: %d\n", pasi);
    }

    fclose(file); //inchidem fisierul

    return 0;
}

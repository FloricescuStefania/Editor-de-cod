#define ALGORITM_H_

int min(int x,int y,int z);
int pasi_min(char fragment_de_cod[], char regula[]);
